﻿using System;
namespace BookRental.WebContracts.WebContracts
{
    public class CreateUserResponse
    {
        public CreateUserResponse()
        {
        }
    }
}
