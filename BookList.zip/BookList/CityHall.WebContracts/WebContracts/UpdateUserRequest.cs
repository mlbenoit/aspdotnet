﻿using System;
namespace BookRental.WebContracts.WebContracts
{
    public class UpdateUserRequest
    {
        public UpdateUserRequest()
        {
        }
    }
}
