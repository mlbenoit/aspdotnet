﻿using System;
namespace BookRental.WebContracts
{
    public class CreateAdminResponse
    {
        public CreateAdminResponse()
        {
        }
    }
}
