using System;
using Microsoft.AspNetCore.Identity;

namespace BookRental.Entities
{
    public class UserRoleEntity:IdentityRole
    {
        

    }
}
